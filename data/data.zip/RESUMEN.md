# Extracción de septiembre: sistemas A y B

Fuente: el Prometheus de cada sistema. A: `localhost:9090` en 204.168.203.32. B: NodePort `31083` en 178.105.104.95.
Las ventanas se detectaron con `sum(rate(data_receiving_frames_total[1m]))`. Todas las horas están en UTC.

## Ventanas usadas

| sistema | corrida | inicio → fin |
|---|---|---|
| A | escalera 1/10/50/100 | 2026-09-17 16:10 → 18:50 |
| A | 12 h a 100 fps | 2026-09-18 05:20 → 17:25 |
| B | escalera 1/10/50/100 | 2026-09-23 06:20 → 09:00 |
| B | 12 h a 100 fps + chaos | 2026-09-23 12:30 → 2026-09-24 00:35 |

## 1. Procesador y memoria del nodo (Tabla 9, Fig. 3)

Media por nivel. La CPU es `100*(1-idle)` y la memoria es `MemTotal-MemAvailable` en MiB. Los nodos son de 2 vCPU y 3,8 GiB.

| nivel fps | A CPU % | B CPU % | B − A (pts) | A mem MiB | B mem MiB | A − B (MiB) |
|---|---|---|---|---|---|---|
| 0 (reposo) | 4,2 | 24,2 | 20,0 | 3419 | 2923 | 496 |
| 1 | 6,0 | 24,7 | 18,7 | 3338 | 2825 | 513 |
| 10 | 13,4 | 35,1 | 21,7 | 3337 | 2836 | 501 |
| 50 | 39,4 | 61,1 | 21,7 | 3343 | 2855 | 488 |
| 100 | 66,8 | 81,9 | 15,1 | 3384 | 2885 | 499 |
| 12 h (100) | 66,7 | 84,0 | 17,3 | 3448 | 2950 | 498 |

### Cifras de la conclusión

- **Procesador.** Bajo carga, B consume entre **15,1 y 21,7 puntos** más que A.
- **Memoria.** A ocupa **~490–515 MiB más** que B, estable en todos los niveles y en las 12 h.
- ⚠️ En reposo B ya está en ~24 % de CPU (plano de control de k3s). Si la tesis compara CPU neta sobre el reposo, la brecha cambia bastante.

## 2. Memoria por servicio (Fig. 4)

Media en MiB a 100 fps durante las 12 h. En B es la RSS sumada de las réplicas. En A es la RSS de los servicios Python/.NET y `jvm_memory_used` en Java.

| servicio | A (18/09) | B (23/09) |
|---|---|---|
| data-receiving | 284 | 45 |
| data-management | 298 (JVM) | 39 |
| early-warning | 60 (solo la instancia :8092) | 63 |
| data-analysis | 255 | 264 |
| project-management | 137 (JVM) | 14 |
| user-management | 127 (JVM) | 19 |

⚠️ En A, el uso de JVM no es RSS: la RSS real de los procesos Java es mayor. Ningún Prometheus mide MySQL, Redis ni RabbitMQ por proceso ni por contenedor.

## 3. Saturación de early-warning (Fig. 5, 7.5, conclusión)

**En la corrida del 23/09 no hubo saturación.**

| indicador | B (23/09) |
|---|---|
| cola `early_warning.evaluate` | 0–12 en régimen; máx. 759 durante el kill de RabbitMQ |
| consumo early-warning | **99,7 fps** (media), igual a la entrada |
| dead letter `sensors.dead_letter` | **0** |

Con los datos del 23/09, B procesa los 100 fps sin backlog.

## 4. Contadores ante inyecciones (Tabla 10, 7.6): B, 12 h del 23/09

Ventanas de 40 min alrededor de cada inyección. Los tiempos se infieren de t+2h, t+6h y t+10h y de los reinicios de pods. Los snapshots de chaos de septiembre no están en el servidor: deben estar en el cliente.

| inyección (≈) | buffer Redis máx. | cola EW máx. | cola DM máx. | fps mín. | descartados DR / EW | DLQ DM |
|---|---|---|---|---|---|---|
| kill-rabbitmq, 14:30 | **11 245** | 759 | 1046 | 69,4 | 0 / 0 | 0 |
| pause-data-management, 18:30 | 73 | 13 | 56 | 96,1 | 0 / 0 | 0 |
| netem EW→DA, 22:30 (breaker abierto = 1) | 267 | 44 | 8 | 88,4 | 0 / 0 | 0 |

En las 12 h no hubo ningún descarte en `data_receiving_messages_dropped_total`, `ew_messages_dropped_total` ni `dm_messages_dlq_total`.

## 5. Cola de evaluación de A durante las 12 h: no se puede recuperar

- El Prometheus de A no scrapea RabbitMQ, así que no hay `rabbitmq_queue_*`.
- Solo scrapea 1 de los 2 consumidores de early-warning (:8092; el :8088 no está en la configuración).
- **Evidencia indirecta:** el :8092 procesó 50,0 fps estables (rango de 46,5 a 58,5) durante las 12 h, con 100 fps publicados. Con round-robin entre 2 consumidores eso da ≈100 fps en total sin deriva, y no hubo descartes. Aun así, no es una medición directa de la cola.
- Para medirla directamente hay que agregar RabbitMQ y el :8088 al scrape de A y repetir la corrida.

## Archivos

- `*-timeseries.csv`: series por minuto con fps, CPU y memoria del nodo, y memoria y CPU por servicio.
- `*-saturation.csv`: series cada 5 min de las 12 h con colas, consumo, descartes, buffer y reinicios.
- `resources-summary.json`: media, mediana, mínimo, máximo y n por nivel.
- ⚠️ `cpu_pct_data-analysis` de A da 300–380 %, lo que no es plausible: probablemente es un artefacto de la métrica. Conviene ignorarla.
